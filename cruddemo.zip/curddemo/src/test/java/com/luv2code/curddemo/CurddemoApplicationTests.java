package com.luv2code.curddemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CurddemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
